require('dotenv').config();
const fs = require('fs');
const http = require('http');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { WebSocketServer } = require('ws');
const { initDatabase } = require('./config/db');
const { MediaController } = require('./controllers/MediaController');
const { attachWebSocket } = require('./controllers/SocketController');
const { authMiddleware } = require('./middleware/authMiddleware');
const apiRoutes = require('./routes/apiRoutes');

const PORT = process.env.PORT || 3000;
const app = express();

const allowedOrigins = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(',').map((o) => o.trim())
  : true;

app.use(cors({ origin: allowedOrigins }));
app.use(express.json({ limit: '8mb' }));

// Authenticated & XSS-hardened media serving
app.use(
  '/uploads',
  authMiddleware,
  (_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', "default-src 'none'");
    next();
  },
  express.static(MediaController.uploadsDir)
);

app.use('/api', apiRoutes);

// Serve built React Native Web bundle (client/dist) on the same port
const clientDistDir = path.join(__dirname, '..', '..', 'client', 'dist');
if (fs.existsSync(clientDistDir)) {
  app.use(express.static(clientDistDir));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(clientDistDir, 'index.html'));
  });
}

const server = http.createServer(app);
const wss = new WebSocketServer({ server });
attachWebSocket(wss);

initDatabase()
  .then(() => {
    server.listen(PORT, () => {
      console.log(`PulseLink MVC Server running on http://localhost:${PORT} (MySQL/MariaDB)`);
    });
  })
  .catch((err) => {
    console.error('Database connection failed:', err.message);
    process.exit(1);
  });
