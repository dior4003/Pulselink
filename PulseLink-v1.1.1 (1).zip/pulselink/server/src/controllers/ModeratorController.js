const { verifyPassword, signToken } = require('../auth');
const { UserModel } = require('../models/UserModel');
const { ModeratorModel } = require('../models/ModeratorModel');

const ModeratorController = {
  async login(req, res) {
    try {
      const { identifier, password, modPasskey } = req.body || {};
      const expectedKey = process.env.MOD_PASSKEY || 'pulselink-mod-2026';
      if (!modPasskey || modPasskey !== expectedKey) {
        return res.status(403).json({ error: 'Moderator maxfiy kaliti noto‘g‘ri' });
      }
      if (!identifier || !password) {
        return res.status(400).json({ error: 'Login va parolni kiriting' });
      }
      const userRecord = await UserModel.findByIdentifier(identifier);
      if (!userRecord || !userRecord.password_hash || !verifyPassword(password, userRecord.password_hash)) {
        return res.status(401).json({ error: 'Login yoki parol noto‘g‘ri' });
      }
      if (userRecord.role !== 'moderator' && userRecord.role !== 'admin') {
        return res.status(403).json({ error: 'Bu hisobga moderatorlik huquqi berilmagan' });
      }
      if (userRecord.is_banned) {
        return res.status(403).json({ error: 'Hisob bloklangan' });
      }

      const modToken = signToken({
        userId: userRecord.id,
        role: userRecord.role,
        scope: 'moderator',
      });
      const moderator = await UserModel.findById(userRecord.id);
      res.json({ modToken, moderator });
    } catch (err) {
      res.status(500).json({ error: 'Moderator kirishida xatolik: ' + err.message });
    }
  },

  async stats(_req, res) {
    const stats = await ModeratorModel.getStats();
    res.json({ stats });
  },

  async listUsers(_req, res) {
    const users = await ModeratorModel.listAllUsers();
    res.json({ users });
  },

  async toggleBan(req, res) {
    const { isBanned } = req.body || {};
    if (req.params.id === req.moderator.id) {
      return res.status(400).json({ error: 'O‘zingizni bloklay olmaysiz' });
    }
    await ModeratorModel.setBan(req.params.id, Boolean(isBanned));
    res.json({ ok: true });
  },

  async listReports(_req, res) {
    const reports = await ModeratorModel.listReports();
    res.json({ reports });
  },

  async resolveReport(req, res) {
    await ModeratorModel.resolveReport(req.params.id);
    res.json({ ok: true });
  },

  async deleteMessage(req, res) {
    await ModeratorModel.deleteMessage(req.params.id);
    res.json({ ok: true });
  },

  async submitReport(req, res) {
    const { targetUserId, reason } = req.body || {};
    if (!targetUserId || !reason) {
      return res.status(400).json({ error: 'Shikoyat sababini kiriting' });
    }
    const id = await ModeratorModel.createReport({
      reporterId: req.user.id,
      targetUserId,
      reason,
    });
    res.status(201).json({ id, ok: true });
  },
};

module.exports = { ModeratorController };
