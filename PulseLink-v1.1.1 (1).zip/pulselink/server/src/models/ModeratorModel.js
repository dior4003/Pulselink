const crypto = require('crypto');
const { getPool } = require('../config/db');
const { mapUser } = require('./UserModel');

const ModeratorModel = {
  async getStats() {
    const [[{ totalUsers }]] = await getPool().query(`SELECT COUNT(*) AS totalUsers FROM users`);
    const [[{ bannedUsers }]] = await getPool().query(`SELECT COUNT(*) AS bannedUsers FROM users WHERE is_banned = 1`);
    const [[{ totalMessages }]] = await getPool().query(`SELECT COUNT(*) AS totalMessages FROM messages`);
    const [[{ totalCalls }]] = await getPool().query(`SELECT COUNT(*) AS totalCalls FROM calls`);
    const [[{ openReports }]] = await getPool().query(`SELECT COUNT(*) AS openReports FROM reports WHERE status = 'open'`);
    return { totalUsers, bannedUsers, totalMessages, totalCalls, openReports };
  },

  async listAllUsers() {
    const [rows] = await getPool().query(`SELECT * FROM users ORDER BY created_at DESC LIMIT 200`);
    return rows.map(mapUser);
  },

  async setBan(userId, isBanned) {
    await getPool().query(`UPDATE users SET is_banned = ? WHERE id = ?`, [isBanned ? 1 : 0, userId]);
  },

  async createReport({ reporterId, targetUserId, reason }) {
    const id = crypto.randomUUID();
    await getPool().query(
      `INSERT INTO reports (id, reporter_id, target_user_id, reason) VALUES (?, ?, ?, ?)`,
      [id, reporterId, targetUserId, String(reason || '').slice(0, 255)]
    );
    return id;
  },

  async listReports() {
    const [rows] = await getPool().query(
      `SELECT r.*,
              rep.display_name AS reporter_name, rep.email AS reporter_email,
              tgt.display_name AS target_name, tgt.email AS target_email
       FROM reports r
       INNER JOIN users rep ON rep.id = r.reporter_id
       INNER JOIN users tgt ON tgt.id = r.target_user_id
       ORDER BY r.created_at DESC
       LIMIT 100`
    );
    return rows.map((r) => ({
      id: r.id,
      reason: r.reason,
      status: r.status,
      createdAt: r.created_at,
      reporterName: r.reporter_name,
      targetUserId: r.target_user_id,
      targetName: r.target_name,
    }));
  },

  async resolveReport(reportId) {
    await getPool().query(`UPDATE reports SET status = 'resolved' WHERE id = ?`, [reportId]);
  },

  async deleteMessage(messageId) {
    await getPool().query(`DELETE FROM messages WHERE id = ?`, [messageId]);
  },
};

module.exports = { ModeratorModel };
